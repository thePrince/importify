#!/bin/sh
#make this script executable: 'chmod +x run.sh'
#must have python installed, and added to your PATH so that the 'python' command works

python authServer.py
python songAdder.py