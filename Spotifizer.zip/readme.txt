Spotifizer: a utility to import local music libraries to your Spotify account

Dependencies: spotipy ('pip install spotipy')

launch the program with './run.sh'
follow command line prompts for input such as filePath and username

individual components (getSongs, songAdder, authServer) can be run independently with added print statements for debugging